The matrices are either directly extracted from the papers (majority of SourceMatrices) referred to in their filename or
have been transformed in some way (dividing by the maximum value) (transformedMatrices) in which case one can trivially retransform them.
Some matrices may have the diagonal filled with 1 (similarity) or 0 (distance) or values have been ported to
the empty matrix half.

IN ANY CASE PLEASE QUOTE THE ORIGINAL PAPERS, the references to which 

can be found in Müller, S. T., & Weidemann, C. T. (2011). Alphabetic letter 
identification: Effects of perceivability, similarity, and bias. Acta psychologica, 139(1), 19-37.